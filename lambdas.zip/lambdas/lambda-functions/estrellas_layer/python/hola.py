
def hello(self, saludo):
    print(saludo)
