import sys
import os
import logging
from hola import Hola

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Agregar logs para verificar rutas
python_path = sys.path

# Verificar si el archivo está en /opt/python
opt_python_exists = os.path.exists("/opt/python")
opt_python_files = os.listdir("/opt/python") if opt_python_exists else []
opt_python_contents = os.listdir("/opt") if opt_python_exists else []


file_path = "/opt/python/hola.py"

if os.path.exists(file_path):
    logger.info(f"El archivo {file_path} SÍ existe en la capa.")
else:
    logger.error(f"ERROR: No se encontró {file_path}.")

def lambda_handler(event, context):
    logger.info("Evento recibido: %s", event)

    obj = Hola()
    obj.hello("Hola desde Lambda!")
    
    return {
        "statusCode": 200,
        "body": {
            "opt_python_contents": opt_python_contents,
            "message": "Función ejecutada correctamente",
            "python_path": python_path,
            "opt_python_exists": opt_python_exists,
            "opt_python_files": opt_python_files
        }
    }
