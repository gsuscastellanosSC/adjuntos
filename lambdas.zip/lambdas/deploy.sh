#!/bin/bash

cd lambda-functions/autenticacion && zip -r autenticacion.zip . && cd ..
cd authorizer && zip -r authorizer.zip . && cd ..
cd canje_estrella && zip -r canje_estrella.zip . && cd ..
cd consulta_estrella && zip -r consulta_estrella.zip . && cd ..
cd devolucion_estrella && zip -r devolucion_estrella.zip . && cd ..
cd reversa_linea_estrella && zip -r reversa_linea_estrella.zip . && cd ..
cd estrellas_layer && zip -r estrellas_layer.zip * && cd ..

aws s3 mb s3://my-bucket-name --endpoint-url http://localhost:4566

cd /c/Users/jacastellanos/repos/gitHub/lambdas

aws s3 cp lambda-functions/autenticacion/autenticacion.zip s3://my-bucket-name/lambda-functions/autenticacion/autenticacion.zip --endpoint-url http://localhost:4566
aws s3 cp lambda-functions/authorizer/authorizer.zip s3://my-bucket-name/lambda-functions/authorizer/authorizer.zip --endpoint-url http://localhost:4566
aws s3 cp lambda-functions/canje_estrella/canje_estrella.zip s3://my-bucket-name/lambda-functions/canje_estrella/canje_estrella.zip --endpoint-url http://localhost:4566
aws s3 cp lambda-functions/consulta_estrella/consulta_estrella.zip s3://my-bucket-name/lambda-functions/consulta_estrella/consulta_estrella.zip --endpoint-url http://localhost:4566
aws s3 cp lambda-functions/devolucion_estrella/devolucion_estrella.zip s3://my-bucket-name/lambda-functions/devolucion_estrella/devolucion_estrella.zip --endpoint-url http://localhost:4566
aws s3 cp lambda-functions/reversa_linea_estrella/reversa_linea_estrella.zip s3://my-bucket-name/lambda-functions/reversa_linea_estrella/reversa_linea_estrella.zip --endpoint-url http://localhost:4566
aws s3 cp lambda-functions/estrellas_layer/estrellas_layer.zip s3://my-bucket-name/estrellas_layer.zip --endpoint-url http://localhost:4566


cd /c/Users/jacastellanos/repos/gitHub/apiGateway

aws cloudformation create-stack --stack-name api-gateway-stack --template-body file://src/template.yml --endpoint-url http://localhost:4566

cd /c/Users/jacastellanos/repos/gitHub/lambdas

aws cloudformation create-stack --stack-name lambdas-stack --template-body file://src/template.yml --parameters ParameterKey=S3BucketName,ParameterValue=my-bucket-name --endpoint-url http://localhost:4566

aws cloudformation list-stacks --endpoint-url http://localhost:4566

